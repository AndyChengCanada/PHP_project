-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2024 at 04:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `item_desc` varchar(50) NOT NULL,
  `qty` int(6) NOT NULL,
  `price` double NOT NULL,
  `img_src` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `cat_id`, `item_name`, `item_desc`, `qty`, `price`, `img_src`) VALUES
(1, 1, 'THESSALIA', 'recycled timber and mango wood, 200cm, natural', 10, 799, 'images\\table0001.webp'),
(2, 1, 'JERRY', 'wood and metal, 160 cm, walnut', 8, 299, 'images\\table0002.webp'),
(3, 1, 'METZ', 'glass and wood, 140 cm, brown', 3, 329, 'images\\table0003.webp'),
(4, 2, 'RAVEL', 'king-size w/ storage, cream', 15, 999, 'images\\bed0004.jpg'),
(5, 2, 'CARME', 'king size, dark grey', 8, 699, 'images\\bed0005.webp'),
(6, 2, 'VALENCE', ' velvet, queen size, grey', 3, 899, 'images\\bed0006.webp'),
(7, 3, 'SANDY', 'rust', 1, 179, 'images\\chair0007.webp'),
(8, 3, 'ODENSE', 'black', 2, 139, 'images\\chair0008.webp'),
(9, 3, 'SHARON', 'velvet, armchair, beige', 3, 169, 'images\\chair0009.webp');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
